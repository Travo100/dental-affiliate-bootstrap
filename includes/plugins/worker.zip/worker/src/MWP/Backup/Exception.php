<?php

/**
 * Backup Exception
 *
 * @version 1.0
 * @author  Ivan Batić
 */
class MWP_Backup_Exception extends Exception {

}
